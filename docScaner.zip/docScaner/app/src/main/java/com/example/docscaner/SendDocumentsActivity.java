package com.example.docscaner;

import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.AdapterView;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import java.io.File;
import android.widget.TextView;
import java.io.IOException;
import java.util.ArrayList;
import android.widget.Spinner;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
public class SendDocumentsActivity extends AppCompatActivity implements OnItemSelectedListener{
    TextView selection = null;
    ArrayList<File> documents;
    String selectClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_document);

        documents = (ArrayList<File>)getIntent().getSerializableExtra(MainActivity.EXTRA_DOCUMENTS);
        System.out.println(documents);
        Spinner spinner = findViewById(R.id.classesList);
        GridView gallery = findViewById(R.id.galleryGridView);
        gallery.setAdapter(new ImageAdapter(this, documents));

        final ArrayList<String> classes = new ArrayList<>();

        HTTP Http = new HTTP();

        Http.get("http://192.168.31.101:3010/api/getClasses", new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String jsonData = response.body().string();
                System.out.println(jsonData);
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(jsonData);
                    JSONArray jsonArray=jsonObject.getJSONArray("collation");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1=jsonArray.getJSONObject(i);
                        String name_class=jsonObject1.getString("name");
                        classes.add(name_class);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //System.out.println(call);
            }
        });

        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, classes);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        // Применяем адаптер к элементу spinner

        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        // Get the Intent that started this activity and extract the string
        //Intent intent = getIntent();
        //ArrayList<File>  doc;
       // doc = (ArrayList<File>) intent.getParcelableArrayListExtra(MainActivity.EXTRA_DOCUMENTS);

        // Capture the layout's TextView and set the string as its text
        //System.out.println(doc);
    }


    public void send(View view) {

        System.out.println(selectClass);
        System.out.println(documents);

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // An item was selected. You can retrieve the selected item using
        selectClass = parent.getItemAtPosition(position).toString();
        System.out.println(selectClass);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


}