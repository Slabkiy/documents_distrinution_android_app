
package com.example.docscaner;
import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import java.io.File;
public class HTTP {
    OkHttpClient client = new OkHttpClient();
    public void get(String url, Callback callback){
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(callback);
    }

    /*public void post(String url, ArrayList<File> documents, Callback callback){

    }*/

}
